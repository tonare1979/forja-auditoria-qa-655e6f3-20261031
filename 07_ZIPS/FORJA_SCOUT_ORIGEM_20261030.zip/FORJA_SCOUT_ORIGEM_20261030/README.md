# FORJA Scout | Integridade de origem em edição histórica

Base: 102f8885deba3c7bb1f6db60e08641e4a9215dda
Novo commit: c7f15d592d35ba16abe1cf2e052100583f42dec1
Referência validada (não substituída): 1ac26422920a806811b5067f19f629dfb862ce11.

## Alterações
- Editor marca origem específica de cada exercício e série enquanto edita; itens novos têm origem -1.
- Merge usa o índice da origem na sessão imutável, não a posição atual; não herda metadados se o nome do exercício muda.
- Marcadores temporários são removidos do registro persistido.
- Inclusão e exclusão não transferem IDs, metadados nem campos auxiliares de itens anteriores.

## Testes
`node tests/scout-history-origin.mjs`
`for f in tests/scout*.mjs; do node "$f" || exit 1; done`
`git diff HEAD^ HEAD --check`

red.log: teste novo no commit anterior falhou; green.log: 16 suítes Scout passaram, incluindo a nova.

## Limites
Os marcadores são referências temporárias dentro da sessão original, não identificadores permanentes entre dispositivos. Alteração para outro exercício com o mesmo nome não pode ser distinguida automaticamente; o campo deve ser preservado apenas quando a edição mantém sua origem. Sem teste real de navegador, persistência ou sincronização. Nenhum deploy.
